# Although this app is freeware, reproduction, monetizing or publishing it on Google Play Store without my written permission is prohibited.
